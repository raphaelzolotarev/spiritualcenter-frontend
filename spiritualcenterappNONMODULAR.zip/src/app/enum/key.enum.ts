export enum Key {
    TOKEN = '[KEY] TOKEN',
    REFRESH_TOKEN = '[REFRESH] REFRESH_TOKEN'
}